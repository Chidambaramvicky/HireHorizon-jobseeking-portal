import React from 'react';
// import './Services.css';
import i1 from'./Assets/images/i1.jpg'
import inter from'./Assets/images/inter.webp'
import interplace from'./Assets/images/interplace.webp'
import jobs from'./Assets/images/jobs.jpg'
import group from'./Assets/images/group.avif'
import un from'./Assets/images/un.jpg'
import res from'./Assets/images/res.png'
import recu from'./Assets/images/recu.png'
import './Services.css'
import new3 from'./Assets/images/new3.jpg'
import Navbar from './Navbar';

const Services = () => {
  return (
    <div className="services-container2">
   <Navbar/>
      <div className="main-content2">
        <h1>Move ahead in career, faster</h1>
        <h2>with our paid services</h2>
        <div className="services2">
          <div className="service-item2">
            <div className="badge">MOST POPULAR</div>
            <img src={inter} alt="Priority Applicant" className="service-image2"  style={{ width: '225px', height: 'auto' }}/>
            <div className="service-content2">
              <h3>RESUME DISPLAY</h3>
              <p className='para2'>Increase your Profile Visibility to recruiters up to 3 times.<br /></p>
              <p><span>Subscription starts from</span> </p>
                <strong>₹890 for 1 Month</strong>
            <span>
                 {/* <a href="#learn-more">KNOW MORE</a> */}
                </span> 
            </div>
          </div>
          <div className="service-item2">
            <div className="badge recommended2">RECOMMENDED</div>
            <img src={i1} alt="Resume Display" className="service-image2" />
            <div className="service-content2">
              <h3>PRIORITY APPLICANT</h3>
              <p>Increase your chance of getting a call.<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹971 for 3 Months</strong>
              {/* <a href="#learn-more">KNOW MORE</a> */}
            </div>
          </div>
          <div className="service-item2">
            <div className="badge free-trial2">Free Trial</div>
            <img src={interplace} alt="AI Mock Interview" className="service-image2"  style={{ width: '250px', height: '160px' }}/>
            <div className="service-content2">
              <h3>AI Mock Interview</h3>
              <p>Personalised AI driven mock interviews for your profile<br /></p>
             <p> <span>
                Try for free now!
                </span> 
                </p>
              <p><strong>₹296 for 3 Months</strong></p>
              {/* <a href="#learn-more">KNOW MORE</a> */}
            </div>
          </div>
          <div className="service-item2">
            <div className="badge recommended2">RECOMMENDED</div>
            <img src={group} alt="Resume Display" className="service-image2" />
            <div className="service-content2">
              <h3>Group Discussion</h3>
              <p>Enhance your communication skills structured group!<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹1001 for 4 Months</strong>
              {/* <a href="#learn-more">KNOW MORE</a> */}
            </div>
          </div>
        </div>
        <div className="new-services2">
        
          <div className="service-item2">
            
          <div className="badge recommended2">New</div>
            <img src={jobs} alt="Jobs for You" className="service-image2"  style={{ width: '250px', height: '170px' }} />
            <div className="service-content2">
              <h3>JOBS FOR YOU</h3>
              <p>Personalized job based on your profile!<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹16000 for 4 Months</strong>
            </div>
          </div>
          <div className="service-item2">
          <div className="badge recommended2">RECOMMENDED</div>
            <img src={res} alt="Resume Critique" className="service-image2" />
            <div className="service-content2">
              <h3>RESUME WRITING </h3>
              <p>Resume tailored to highlight your achievements.<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹599 for 3 Months</strong>
            </div>
          </div>
          <div className="service-item2">
          <div className="badge recommended2">Free Trial</div>
            <img src={recu} alt="Recruiter Connection" className="service-image2"style={{ width: '250px', height: '165px' }} />
            <div className="service-content2">
              <h3>RECRUITER CONNECTION</h3>
              <p>Directly connect with recruiters to increase your chances.<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹10000 for 4 Months</strong>
            </div>
            
         
          </div>
          <div className="service-item2">
          <div className="badge recommended2">MOST POPULAR</div>
            <img src={un} alt="Resume Critique" className="service-image2" style={{ width: '250px', height: '163px' }}/>
            <div className="service-content2">
              <h3>RESUME CRITIQUE</h3>
              <p> Receive expert feedback on your resume to improves.<br /></p>
              <p><span>
                Subscription starts from 
                </span></p>
                <strong>₹399 for 3 Months</strong>
            </div>
          </div>
        </div>
      </div>
      <div className="contact-section2">
        <div className="contact-box2">
          <h3>Talk to Us</h3><br></br>
          <p>Call us Toll Free: 1800-102-5557<br /><br></br>
          (9.00 AM to 9.00 PM IST)</p><br></br>
          <p>International Customer Call: +91-120-4021100</p><br></br>
          <p>For bulk queries call: 18001034477</p>
          <br></br>
          <br></br>
          <img src={new3} alt="Resume Display" className="service-image2"  style={{width:'380px',height:'300px' }} />
        </div>
        <div className="contact-form2">
          <h3>CONTACT US</h3>
          <p>The information will only be used to reach out to you for Naukri related services.</p>
          <form>
            <label>Name*</label>
            <input type="text" placeholder="Type your name here" required />
            <label>Email ID*</label>
            <input type="email" placeholder="Type your email here" required />
            <label>Mobile*</label>
            <input type="tel" placeholder="Type your mobile number" required />
            <label>Write your query here*</label>
            <textarea placeholder="e.g. I am interested" required></textarea>
            <button type="submit">CALL ME BACK</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Services;
