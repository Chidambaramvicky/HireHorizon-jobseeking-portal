import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './JobSearchPage.css';
import Navbar from './Navbar';

const JobSearchPage = () => {
  const [filters, setFilters] = useState({
    workMode: '',
    experience: 1,
    department: [],
    salary: [],
    companyType: []
  });

  const jobListings = [
    {
      id: 1,
      title: 'Full Stack Developer',
      company: 'Impleox Tech',
      date: '09 Nov - 10 Dec',
      salary: '₹ 5 - 6 Lacs P.A.',
      location: 'Chennai',
      experience: '2-4 Yrs',
      qualification: 'Bachelors degree or equivalent experience in a relevant field',
      tags: ['Data Entry Operator', 'Data entry operation', 'Data entry', 'Operating', 'Data'],
      rating: 4.9,
      reviews: '87 Reviews',
      type: 'Exclusive For Men and Women',
      posted: '11 Days ago',
    },
    {
      id: 2,
      title: 'Data Entry Operator (Non-Voice Process)',
      company: 'Medcode Services',
      date: '17 Jul - 26 Jul',
      salary: '₹ 1 - 1.5 Lacs P.A.',
      location: 'Coimbatore',
      experience: '1 - 2 Yrs',
      shift: 'Night',
      eligibility: 'Any graduate can apply (from the year 2022, 2023)',
      tags: ['fresher', 'Typing', 'Non Voice', 'Data Processing', 'Data Entry Operation', 'Back Office'],
      type: 'Walk-in',
      posted: '9 Days ago',
    },
    {
      id: 3,
      title: 'WFH - Data Entry',
      company: 'Infognana (IG) Solutions',
      date: '06 Oct - 09 Nov',
      salary: '₹ 4 - 5 Lacs P.A.',
      location: 'Coimbatore',
      experience: '1-4 Yrs',
      qualification: 'Bachelors degree or equivalent experience in a relevant field',
      tags: ['Data Entry Operator', 'Data entry operation', 'Data entry', 'Operating', 'Data'],
      rating: 4.2,
      reviews: '57 Reviews',
      type: 'Exclusive For Women',
      posted: '30 Days ago',
    },
    {
      id: 4,
      title: 'Hiring For HDFC | On Roll Job',
      company: 'HDFC Sales',
      date: '17 Aug - 17 Sep',
      salary: '₹ 2.5-3.5 Lacs P.A.',
      location: 'Chennai',
      experience: '1 - 3 Yrs',
      qualification: 'Bachelors degree or equivalent experience in a relevant field',
      tags: ['Banking Sales ', 'Fresher ', 'Home Loan', 'Insurance', 'Field Sales', 'Direct Sales'],
      rating: 4.2,
      reviews: '57 Reviews',
      type: 'Exclusive For Men',
      posted: '10 Days ago',
    }
  ];

  const handleClearAll = () => {
    setFilters({
      workMode: '',
      experience: 1,
      department: [],
      salary: [],
      companyType: []
    });
  };

  const handleCheckboxChange = (category, value) => {
    setFilters(prevFilters => {
      const updatedCategory = prevFilters[category].includes(value)
        ? prevFilters[category].filter(item => item !== value)
        : [...prevFilters[category], value];
      return {
        ...prevFilters,
        [category]: updatedCategory
      };
    });
  };

  return (
    <div className="jobsearch-page">
      <Navbar />
      
      <div className="content" style={{ backgroundColor: 'white' }}>
   
        <aside className="filters">
          <button className="clear-all2" onClick={handleClearAll}>Clear All</button>

          <div className="filter-group">
            <h4>Work mode</h4>
            <label>
              <input
                type="checkbox"
                checked={filters.workMode === 'Work from office'}
                onChange={() => setFilters({ ...filters, workMode: 'Work from office' })}
              />
              Work from office (519)
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.workMode === 'Hybrid'}
                onChange={() => setFilters({ ...filters, workMode: 'Hybrid' })}
              />
              Hybrid (14)
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.workMode === 'Remote'}
                onChange={() => setFilters({ ...filters, workMode: 'Remote' })}
              />
              Remote (5)
            </label>
          </div>

          <div className="filter-group">
            <h4>Experience</h4>
            <input
              type="range"
              min="0"
              max="30"
              value={filters.experience}
              onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
            />
            <div>{filters.experience} Yrs</div>
          </div>

          <div className="filter-group">
            <h4>Department</h4>
            <label>
              <input
                type="checkbox"
                checked={filters.department.includes('Sales Development')}
                onChange={() => handleCheckboxChange('department', 'Sales Development')}
              />
              Sales Development
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.department.includes('Customer Success')}
                onChange={() => handleCheckboxChange('department', 'Customer Success')}
              />
              Customer Success
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.department.includes('Human Resources')}
                onChange={() => handleCheckboxChange('department', 'Human Resources')}
              />
              Human Resources
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.department.includes('Consulting')}
                onChange={() => handleCheckboxChange('department', 'Consulting')}
              />
              Consulting
            </label>
          </div>

          <div className="filter-group">
            <h4>Salary</h4>
            <label>
              <input
                type="checkbox"
                checked={filters.salary.includes('0-3 Lakhs')}
                onChange={() => handleCheckboxChange('salary', '0-3 Lakhs')}
              />
              0-3 Lakhs
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.salary.includes('3-6 Lakhs')}
                onChange={() => handleCheckboxChange('salary', '3-6 Lakhs')}
              />
              3-6 Lakhs
            </label>
          </div>

          <div className="filter-group">
            <h4>Company Type</h4>
            <label>
              <input
                type="checkbox"
                checked={filters.companyType.includes('Corporate')}
                onChange={() => handleCheckboxChange('companyType', 'Corporate')}
              />
              Corporate
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.companyType.includes('Foreign MNC')}
                onChange={() => handleCheckboxChange('companyType', 'Foreign MNC')}
              />
              Foreign MNC
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.companyType.includes('Indian MNC')}
                onChange={() => handleCheckboxChange('companyType', 'Indian MNC')}
              />
              Indian MNC
            </label>
            <label>
              <input
                type="checkbox"
                checked={filters.companyType.includes('StartUp')}
                onChange={() => handleCheckboxChange('companyType', 'StartUp')}
              />
              StartUp
            </label>
          </div>
        </aside>

        <main className="job-listings">
          {jobListings.map((job) => (
            <div className="job-card" key={job.id}>
              <Link to={`/jobdetail/${job.id}`} style={{ textDecoration: 'none' }}>
                <h2>{job.title}</h2>
              </Link>
              <p>{job.company}</p>
              <div className="job-details">
                <span>{job.date}</span>
                <span>{job.salary}</span>
                <span>{job.experience}</span>
                <span>{job.location}</span>
              </div>
              <div className="job-tags">
                {job.tags.map((tag, i) => (
                  <span className="tag" key={i}>{tag}</span>
                ))}
              </div>
              <div className="job-meta">
                <span>{job.type}</span>
                <span>{job.posted}</span>
              </div>
            </div>
          ))}
        </main>
      </div>
    </div>
  );
};

export default JobSearchPage;
