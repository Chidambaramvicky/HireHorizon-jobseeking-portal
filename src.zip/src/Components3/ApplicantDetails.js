import React from 'react';
import { Paper, Typography } from '@mui/material';

const ApplicantDetails = () => {
  return (
    <Paper sx={{ padding: 2 }}>
      <Typography variant="h6">Applicant Details</Typography>
      {/* Applicant details will go here */}
    </Paper>
  );
};

export default ApplicantDetails;
