import React from 'react';
import { Paper, Typography } from '@mui/material';

const AddJob = () => {
  return (
    <Paper sx={{ padding: 2 }}>
      <Typography variant="h6">Add Job</Typography>
      {/* Add job form will go here */}
    </Paper>
  );
};

export default AddJob;
