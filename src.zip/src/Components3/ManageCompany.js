import React from 'react';
import { Paper, Typography } from '@mui/material';

const ManageCompany = () => {
  return (
    <Paper sx={{ padding: 2 }}>
      <Typography variant="h6">Manage Company</Typography>
      {/* Manage company form will go here */}
    </Paper>
  );
};

export default ManageCompany;
